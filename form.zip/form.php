<form action="send.php" method="post">
    <input type="text" name="fio" placeholder="Укажите ФИО" required>
    <input type="text" name="email" placeholder="Укажите E-Mail" required>
    <input type="submit" name="otpravit" value="Отправить">
</form>

